#version 150

// ⚠️ #version 150, NON 330. Lo stars.fsh vanilla dichiara 330 sui client 1.21.9+
// ma 150 su quelli 1.21.6-1.21.8, perche' li' il contesto OpenGL e' 3.2 e uno
// shader 330 NON COMPILA. E uno shader di base che non compila non spegne solo
// le stelle: fa saltare tutto il disegno del cielo, quindi spariscono anche
// sole e luna (e' successo davvero, il 16/09/2026).
// GLSL 150 invece compila su tutti e due i contesti, e qui non si usa niente che
// 150 non abbia. Una texture sola per tutte le versioni.

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;

// La direzione della stella nel cielo. I quattro angoli di una stessa stella
// hanno direzioni quasi identiche (si discostano di due millesimi di radiante),
// quindi qualunque funzione LENTA di questa direzione da' lo stesso valore su
// tutti e quattro: e' cosi' che ogni stella prende un suo colore senza che il
// quadratino si spacchi a meta'.
out vec3 direzioneStella;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    direzioneStella = normalize(Position);
}
