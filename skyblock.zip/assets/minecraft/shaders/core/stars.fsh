#version 150

// ⚠️ #version 150, NON 330. Lo stars.fsh vanilla dichiara 330 sui client 1.21.9+
// ma 150 su quelli 1.21.6-1.21.8, perche' li' il contesto OpenGL e' 3.2 e uno
// shader 330 NON COMPILA. E uno shader di base che non compila non spegne solo
// le stelle: fa saltare tutto il disegno del cielo, quindi spariscono anche
// sole e luna (e' successo davvero, il 16/09/2026).
// GLSL 150 invece compila su tutti e due i contesti, e qui non si usa niente che
// 150 non abbia. Una texture sola per tutte le versioni.

#moj_import <minecraft:dynamictransforms.glsl>

in vec3 direzioneStella;

out vec4 fragColor;

// Rumore LENTO sulla direzione: frequenze basse apposta. Se fossero alte, i
// quattro angoli di una stella prenderebbero valori diversi e la stella
// sembrerebbe sfumata invece che di un colore solo.
float campo(vec3 d, float f, float s) {
    return sin(d.x * f + s)
         * cos(d.y * f * 0.83 - s * 1.7)
         * sin(d.z * f * 1.19 + s * 0.41);
}

void main() {
    vec3 d = direzioneStella;

    float tipo    = campo(d, 23.0, 0.0)  * 0.5 + 0.5;   // che stella e'
    float taglia  = campo(d, 17.0, 2.31) * 0.5 + 0.5;   // quanto e' luminosa

    // Colori stellari veri, dalle azzurre calde alle arancioni fredde.
    // La maggior parte del cielo resta bianca: le colorate devono essere poche,
    // senno sembra un albero di Natale.
    vec3 colore;
    if (tipo < 0.52) {
        colore = mix(vec3(0.70, 0.79, 1.00), vec3(0.97, 0.98, 1.00), tipo / 0.52);
    } else if (tipo < 0.84) {
        colore = mix(vec3(0.97, 0.98, 1.00), vec3(1.00, 0.95, 0.83), (tipo - 0.52) / 0.32);
    } else {
        colore = mix(vec3(1.00, 0.95, 0.83), vec3(1.00, 0.76, 0.56), (tipo - 0.84) / 0.16);
    }

    // Poche stelle molto luminose e tante deboli: elevare al quadrato sposta la
    // distribuzione verso il basso, come nel cielo vero.
    float forza = 0.26 + 1.65 * pow(taglia, 2.3);

    // La Via Lattea. Non si possono aggiungere stelle, ma si possono accendere
    // quelle che gia' stanno vicino a un cerchio massimo: da lontano si legge
    // come una fascia luminosa che attraversa il cielo.
    vec3 poloGalattico = normalize(vec3(-0.42, 0.78, 0.46));
    float distanzaDalPiano = abs(dot(d, poloGalattico));
    float viaLattea = pow(1.0 - min(distanzaDalPiano / 0.34, 1.0), 1.5);
    forza *= 1.0 + viaLattea * 1.85;
    colore = mix(colore, vec3(0.84, 0.89, 1.00), viaLattea * 0.45);

    // NIENTE tremolio, apposta: per animarlo servirebbe GameTime, che sta in
    // globals.glsl - un include che lo stars.fsh vanilla NON importa. Uno shader
    // di base che non compila fa fallire il rendering a tutti i client, quindi
    // qui gli import restano identici all'originale. Il tremolio si potra'
    // aggiungere dopo aver verificato in gioco che tutto il resto regge.
    float f = forza;
    fragColor = vec4(ColorModulator.rgb * colore * min(f, 2.1),
                     clamp(ColorModulator.a * min(f, 1.55), 0.0, 1.0));
}
